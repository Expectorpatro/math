# 决策树算法

本文将以分类任务为主，在最后点出模型在做回归任务时与分类任务的不同之处。

## 信息论

### 信息量

我们想要找一个函数$f(x)$来对事件产生的信息量进行定量的分析，其中$x$代表着一个事件。显然信息量具有如下两个性质：

1. **一件事发生的概率越小，那么这件事发生后产生的信息量越大。** 

2. **如果两件事情独立，那么这两件事情都发生所产生的信息量应该等于每件事情各自发生产生的信息量之和。**

**由(1)，$f(x)$需要与$x$发生的概率呈反比；由(2)，$f(x)$应具有对数的形式，** 因为如果$f(x)=\log\Big(\mathrm{Pr}(x)\Big)$，将$x,y$两个互相独立的事件同时发生的概率记为$\mathrm{Pr}(x,y)$、产生的信息量记为$f(x,y)$，那么：

$$
\begin{align*}
f(x,y)&=\log\Big(\mathrm{Pr}(x,y)\Big)=\log\Big(\mathrm{Pr}(x)\mathrm{Pr}(y)\Big) \\
&=\log\Big(\mathrm{Pr}(x)\Big)+\log\Big(\mathrm{Pr}(y)\Big) \\
&=f(x)+f(y)
\end{align*}

$$

综合考虑以上两点，我们**将一件事情发生所产生的信息量定义为它发生概率倒数的对数**，即：

$$
f(x)=-\log\Big(\mathrm{Pr(x)}\Big)
$$

**对数底的选择是任意的，但在信息论中普遍使用$2$作为对数的底。**

### 信息熵

**熵是可能产生的信息量的期望。**

考虑$n$个彼此独立的事件$x_1,x_2,\dots,x_n$都发生带来的信息熵$g(x)$：

$$
\begin{align*}
    g(x)
    &=\mathrm{E}\Big(f(x_1,x_2,\dots,x_n)\Big) \\
    &=E\Big(\sum_{i=1}^nf(x_i)\Big) \\
    &=\sum_{i=1}^nE(f(x_i)) \\
    &=-\sum_{i=1}^n\mathrm{Pr}(x_i)\log\Big(\mathrm{Pr}(x_i)\Big)
\end{align*}
$$
